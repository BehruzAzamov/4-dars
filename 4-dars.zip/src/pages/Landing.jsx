import ProductDetails from "./ProductList"

function Landing() {
  return (
    <ProductDetails/>
  )
}

export default Landing