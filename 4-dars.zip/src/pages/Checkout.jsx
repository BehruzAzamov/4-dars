import React from 'react'

function Checkout() {
  return (
    <div>Salom</div>
  )
}

export default Checkout