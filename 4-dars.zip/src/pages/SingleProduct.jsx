function SingleProduct() {
  return (
    <div>SingleProduct</div>
  )
}

export default SingleProduct