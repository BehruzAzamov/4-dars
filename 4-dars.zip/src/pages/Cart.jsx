import React from 'react'

function Cart() {
  return (
    <div>Cart</div>
  )
}

export default Cart