import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import productData from '../product.json';


function ProductDetails() {
    const { id } = useParams();
    const [product, setProduct] = useState(null);

    useEffect(() => {
        const fetchProduct = async () => {
            const response = await axios.get(`/api/products/${id}`);
            setProduct(response.data.data);
        };
        fetchProduct();
    }, [id]);

    if (!product) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            <h1>{product.attributes.title}</h1>
            <p>Company: {product.attributes.company}</p>
            <p>Description: {product.attributes.description}</p>
            <p>Featured: {product.attributes.featured ? 'Yes' : 'No'}</p>
            <p>Created: {new Date(product.attributes.createdAt).toLocaleString()}</p>
            <p>Updated: {new Date(product.attributes.updatedAt).toLocaleString()}</p>
            <p>Published: {new Date(product.attributes.publishedAt).toLocaleString()}</p>
            <p>Category: {product.attributes.category}</p>
            <img src={product.attributes.image} alt={product.attributes.title} />
            <p>Price: ${product.attributes.price}</p>
            <p>Shipping: {product.attributes.shipping ? 'Yes' : 'No'}</p>
            <h3>Colors:</h3>
            <ul>
                {product.attributes.colors.map((color, index) => (
                    <li key={index} style={{ backgroundColor: color, width: '50px', height: '50px' }} />
                ))}
            </ul>
        </div>
    );
}

export default ProductDetails;
